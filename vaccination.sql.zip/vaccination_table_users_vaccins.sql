
-- --------------------------------------------------------

--
-- Structure de la table `users_vaccins`
--

DROP TABLE IF EXISTS `users_vaccins`;
CREATE TABLE IF NOT EXISTS `users_vaccins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `id_vaccins` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
