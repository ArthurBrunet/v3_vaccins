
-- --------------------------------------------------------

--
-- Structure de la table `vac_users`
--

DROP TABLE IF EXISTS `vac_users`;
CREATE TABLE IF NOT EXISTS `vac_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `role` enum('user','admin') NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vac_email` (`email`),
  UNIQUE KEY `vac_token` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
