
-- --------------------------------------------------------

--
-- Structure de la table `vac_vaccins`
--

DROP TABLE IF EXISTS `vac_vaccins`;
CREATE TABLE IF NOT EXISTS `vac_vaccins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `categorie` enum('Vivant','Inactive') NOT NULL,
  `obligatoire` enum('Recommandé','Obligatoire') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
